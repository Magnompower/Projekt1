package HarryCotterProject;

public class Person {
    private String navn;
    private int id;

    public Person(String navn, int id) {
        this.navn = navn;
        this.id = id;
    }
    
}
